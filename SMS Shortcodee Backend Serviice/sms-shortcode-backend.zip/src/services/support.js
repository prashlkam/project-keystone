export default async function supportHandler(from, cmd) {
  // create ticket in external system
  return 'Support: our team will contact you.';
}
